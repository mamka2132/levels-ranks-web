<?php ! defined("IN_LR") && die()?>
<div class="back">
    <div class="language_title">Select the language</div>
    <form enctype="multipart/form-data" method="post">
    <div class="language_left">
        <button type="submit" name="EN">
        <div class="language_eng_img"><img src="storage/cache/img/icons/custom/flags/en.svg" class="svg"></div>
        <div class="language_name">English</div></button>
    </div>
    <div class="language_right">
        <button type="submit" name="RU">
        <div class="language_rus_img"><img src="storage/cache/img/icons/custom/flags/ru.svg" class="svg"></div>
        <div class="language_name">Русский</div></button>
    </div>
    </form>
</div>