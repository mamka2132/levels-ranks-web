<?php ! defined("IN_LR") && die()?>
<div class="back">
    <div class="sidebar_title">Сайтбар - По умолчанию</div>
    <form enctype="multipart/form-data" method="post">
    <div class="sidebar_left">
        <button type="submit" name="sidebar_close">
            <div class="sidebar_eng_img"><img src="app/page/custom/install/img/sidebar_close.png"></div>
            <div class="sidebar_name">Свёрнут</div></button>
    </div>
    <div class="sidebar_right">
        <button type="submit" name="sidebar_open">
            <div class="sidebar_rus_img"><img src="app/page/custom/install/img/sidebar_open.png"></div>
            <div class="sidebar_name">Развернут</div></button>
    </div>
    </form>
</div>