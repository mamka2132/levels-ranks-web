<div class="global-container">
    <div class="container-fluid">